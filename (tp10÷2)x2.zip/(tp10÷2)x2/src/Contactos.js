import Navbar from "./Index/Navbar.js"
import Footer from "./Index/Footer.js"

function Contactos() {
    return (
      <div className="QuienesSomos">
        <Navbar />
        
        <Footer />
      </div>
    );
  }
  
  export default Contactos;
  