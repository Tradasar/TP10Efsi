import Navbar from "./Index/Navbar.js"
import Footer from "./Index/Footer.js"

function QuienesSomos() {
    return (
      <div className="QuienesSomos">
        <Navbar />
        <Text>Somos una empresa multinacional a gran escala, la cual ofrece una gran cantidad de variedad en sus productos del baño, como lavatoios, lavatorios o lavatorios, y lavatoios tambien</Text>
        <Footer />
      </div>
    );
  }
  
  export default QuienesSomos;
  