function HeaderAndFooterExample() {
  return (
    <div>
    <div class="container">
    <div class="row">
        <h6>
            Marcas con las que trabajamos
        </h6>
        <div class="col-4">
        <img src="https://i.postimg.cc/j51Lzh5r/ferrum.png"/>
        </div>
        <div class="col-4">
            <img src="https://i.postimg.cc/25fdWrtx/delta.png"/>
        </div>
        <div class="col-2">
            <img src="https://i.postimg.cc/d1gGqFGd/Logo-Negativo.png"/>
        </div>
        <div class="col-2">
            <img src="https://i.postimg.cc/28RnMzkN/logo-ips.png" alt=""/>
        </div>
    </div>
</div>
<div class="container-fluid">
            <footer class="bg-dark width:100% py-3 my-4">
              <ul class="nav justify-content border-bottom pb-3 mb-3">
                <li class="nav-item"><a href="#" class="nav-link px-2 text-white"><img src="https://i.postimg.cc/7Pg5CSkj/logo-byn.png"/></a></li>
                <li class="nav-item"><a href="#" class="nav-link px-2 text-white">Beiro 3300 - Villa del Parque</a></li><br/>
                <li class="nav-item"><a href="#" class="nav-link px-2 text-white">contacto@sanitarioscampana.com.ar</a></li>
                <li class="nav-item"><a href="#" class="nav-link px-2 text-primary"><img src="https://i.postimg.cc/tJCG40yq/tel.png" alt=""/>4503-6015</a></li>
              </ul>
              <p class="text-center text-muted">© 2021 Company, Inc</p>
            </footer>
          </div>
</div>
  );
}

export default HeaderAndFooterExample;