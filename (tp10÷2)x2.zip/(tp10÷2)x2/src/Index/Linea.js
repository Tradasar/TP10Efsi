import Figure from 'react-bootstrap/Figure';

function FigureExample() {
  return (
    <hr style={{
      color: "#c0c0ff",
      backgroundColor: "#c0c0ff",
      height: 10
    }}/>
  );
}

export default FigureExample;