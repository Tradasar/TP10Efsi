import Navbar from "./Index/Navbar.js"
import Footer from "./Index/Footer.js"
import Cards from "./Index/Cards.js"

function Productos() {
    return (
      <div className="QuienesSomos">
        <Navbar />
        <Cards />
        <Footer />
      </div>
    );
  }
  
  export default Productos;
  