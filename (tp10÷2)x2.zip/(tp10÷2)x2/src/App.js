import 'bootstrap/dist/css/bootstrap.min.css';
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Contactos from './Contactos';
import Inicio from './Inicio';
import Productos from './Productos';
import QuienesSomos from './QuienesSomos'

function App() {
  return (
    <BrowserRouter>
    <Routes>
      <Route path="/" element={<Inicio/>}>
        <Route path="/" element={<QuienesSomos/>}/>
        <Route path="/" element={<Productos/>}/>
        <Route path="/" element={<Contactos/>}/>
      </Route>
    </Routes>
    </BrowserRouter>
  );
}

export default App;
