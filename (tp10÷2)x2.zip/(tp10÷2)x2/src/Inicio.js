import Navbar from "./Index/Navbar.js"
import Carousel from "./Index/Carousel.js"
import Cards from "./Index/Cards.js"
import Linea from "./Index/Linea.js"
import Footer from "./Index/Footer.js"

function Inicio() {
    return (
      <div className="Inicio">
        <Navbar />
        <Carousel/> 
        <Cards />
        <Linea />
        <Footer />
      </div>
    );
  }
  
  export default Inicio;
  